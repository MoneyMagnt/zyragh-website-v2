@echo off
cd /d "%~dp0"
call npm run dev
if errorlevel 1 pause
